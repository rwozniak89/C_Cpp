DECLARE global_accumulator INT = 0;

CREATE FUNCTION runningtotal(delay INT, limit INT)
 RETURNS INT
BEGIN
 DECLARE result INT;
 global_accumulator = global_accumulator + delay;
 IF global_accumulator <= limit THEN
  result = global_accumulator;
 ELSE
  result = NULL;
 END IF;
 RETURN result;
END;


CREATE FUNCTION runningtotal_cursor(limit INT)
 RETURNS STRING
BEGIN
 DECLARE accumulator INT = 0;
 DECLARE result STRING = '';
 FOR item IN(SELECT flightnum, delay
  FROM testdb.airline
  WHERE tailnum LIKE 'N3__WN'
   AND airport = 'PHL'
   AND delay > 0
  ORDER BY delay DESC)
 LOOP
  SET accumulator = accumulator + item.delay;
  IF accumulator <= limit
   SET result = result || ',' || item.flightnum || ':' || accumulator;
 END LOOP;
 RETURN SUBSTRING(result, 2);
END;
